/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import Controller.CandidateManager;

/**
 *
 * @author XUAN LINH
 */
public class Main {
    public static void main(String[] args) {
        CandidateManager manager=new CandidateManager();
        manager.runProgram();
    }
}
