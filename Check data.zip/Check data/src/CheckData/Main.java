package CheckData;

import Controllers.CheckDataController;

public class Main {

    public static void main(String[] args) {
        new CheckDataController().run();
    }
}
