package Views;

public class checkDataViews {

    public checkDataViews() {
        System.out.println("====== Validate Progaram ======");
    }
    
    public void inputPhoneNumber(){
        System.out.print("Phone number: ");
    }
    
    public void inputEmail(){
        System.out.print("Email: ");
    }
    
    public void inputDate(){
        System.out.print("Date: ");
    }
    
}
